Java techie

Any logic which we can run in background that we can assign to another thread without blocking the main thread.

We use @Async annotation to execute method asynchronously without blocking main thread.

Use @Async annotation on method which we want to run asynchronusly and in Main application call add @EnableAsync annotation,
so springboot will create implicit bean of SimpleExecutorTaskPool to with default configuration, otherwise
we can also create custom Executor bean with ThreadPoolTaskExecutor class object.

******************************************************************************************

uTube video
@Async in Spring Boot | Code Debugger

How to hanlde exception in asynchronus call:
	To handle these exeption springboot has provided on class i.e AsyncConfigurerSupport,
	that we need to extend and implement custom logic for exception handling by overriding two methods
	
	1 - getAsyncExecutor
	2 - getAsyncUncoughtExceptionHandler
	To implement these two method we will create one configuration class.
	
	After that :
	We need to create AsyncExceptionHandler class by implementing AsyncUncaughtExceptionHandler
	And implement one overrided method which is handleUncaughtException
	i.e
	@Component
	public class AsyncExceptionHandler implements AsyncUncaughtExceptionHandler{
	
		@Override
		public void handleUncaughtException(Throwable ex, Method method, Object... params) {
			// TODO Auto-generated method stub
			System.out.println("--"+method.getName()+" -- "+Arrays.toString(params)+" -- "+ex.getMessage());
		}
	
	} 
	