package com.asyncprograme.config;

import java.util.concurrent.Executor;

import org.springframework.aop.interceptor.AsyncUncaughtExceptionHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.AsyncConfigurerSupport;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.asyncprograme.exceptions.AsyncExceptionHandler;

@Configurable
@EnableAsync
/*public class AsyncConfig {

	
	It is optional, even if we not create ThreadPoolTaskExecutor it will simply create S
	SimpleAsyncTaskExecutor
	
	@Bean(name="taskExecutor")
	public Executor taskExecutor() {
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setCorePoolSize(2);
		executor.setMaxPoolSize(2);
		executor.setQueueCapacity(100);
		executor.setThreadNamePrefix("Thread-");
		executor.initialize();
		return executor;
	}
}*/

public class AsyncConfig extends AsyncConfigurerSupport{
	@Autowired
	private AsyncExceptionHandler asyncExceptionHandler;
	/*
	It is optional, even if we not create ThreadPoolTaskExecutor it will simply create S
	SimpleAsyncTaskExecutor
	*/
	@Bean(name="taskExecutor")
	public Executor taskExecutor() {
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setCorePoolSize(2);
		executor.setMaxPoolSize(2);
		executor.setQueueCapacity(100);
		executor.setThreadNamePrefix("Thread-");
		executor.initialize();
		return executor;
	}
	
	
	public AsyncUncaughtExceptionHandler getAsyncUncaughtExceptionHandler(){
		return asyncExceptionHandler;
	}
	
}