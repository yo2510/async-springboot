package com.asyncprograme.service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.asyncprograme.entity.User;
import com.asyncprograme.repository.UserRepository;

@Service
public class UserService {
	private UserRepository repository;
	private final Logger logger = LoggerFactory.getLogger(UserService.class);
	
	@Async
	public CompletableFuture<List<User>> saveUser(MultipartFile file){
		long startTime = System.currentTimeMillis();
		List<User> users = parseCsv(file);
		logger.info("saving list of user of size "+users.size()+" thead name "+Thread.currentThread().getName());
		long endTime = System.currentTimeMillis();
		repository.saveAll(users);
		logger.info("Total time : "+(endTime-startTime));
		return CompletableFuture.completedFuture(users);
	}
	
	@Async
	public CompletableFuture<List<User>> findAllUser(){
		List<User> users = repository.findAll();
		return CompletableFuture.completedFuture(users);
	}
	
	private List<User> parseCsv(MultipartFile file){
		final List<User> users = new ArrayList<User>();
		try {
			try(BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream()))){
				String line;
				while((line = br.readLine()) != null) {
					String[] data = line.split(",");
					final User user = new User();
					user.setName(data[0]);
					user.setEmailId(data[1]);
					user.setGender(data[2]);
					users.add(user);
				}
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return users;
	}
}
